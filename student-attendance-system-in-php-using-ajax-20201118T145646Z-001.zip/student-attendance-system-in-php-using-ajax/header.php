<?php

//header.php

include('admin/database_connection.php');
session_start();

if(!isset($_SESSION["teacher_id"]))
{
  header('location:homepage.php');
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Student Attendance System in PHP using Ajax</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/dataTables.bootstrap4.min.css">
  <style>
body{
  background-image: url('img1.jpg');
  background-repeat: no-repeat;
   background-attachment: fixed;
  background-size: cover;
}
ul{
  list-style-type: none;
  margin:0;
  padding:0;
  overflow: hidden;
  height:55px;
}
li a{
  font-family: Times new roman;
  font-color:blue;
  font-size:20px;
  font-weight:bold;
  display: block;
  color: ;
  text-align:center;
  padding: 15px 15px;
  text-decoration: none;
  margin-right:20px;
}

</style>
  <script src="js/jquery.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.dataTables.min.js"></script>
  <script src="js/dataTables.bootstrap4.min.js"></script>
</head>
<body>

<nav class="navbar navbar-expand-sm bg-dark navbar-dark"> 
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
      <a class="nav-link" href="index.php">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="profile.php">Select subject</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="attendance.php">Attendance</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="logout.php">Logout</a>
      </li>  
       <li><a class="nav-link" style="margin-left:820px"href="homepage.php">Student Attendance Monitoring System</a></li>

    </ul>
  </div>  
</nav>