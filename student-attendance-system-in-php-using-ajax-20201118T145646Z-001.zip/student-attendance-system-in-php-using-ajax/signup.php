
<!DOCTYPE html>
<html lang="en">
<head>
<title>Signup page</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
 <style>
    body{
  background-image: url('img1.jpg');
  background-repeat: no-repeat;
   background-attachment: fixed;
  background-size: cover;
}
</style>
</head>
<body>
<div class="jumbotron text-center" style="margin-bottom:1px">
  <h1 style="font-family:fantasy">Student Attendance Monitoring System</h1>
</div>

<div class="container">
  <div class="row">
    <div class="col-md-4">

    </div>
<div class="col-md-4" style="margin-top:20px;">
 <div class="card" style=" border: 2px solidrgb(0, 4, 8); border-radius: 0px 0px 10px 10px;">
  <div class="card-header" style="background: rgb(2, 48, 49);text-align:center;color:white;font-size:20px;font-family:fantasy">Teacher signup</div>
<div class="card-body" style="backgorund:rgb(153, 153, 153)">

<form id="form" name="form">
<div class="form-group" style="font-weight:bold">
    <label>Enter EmailID</label>
  <input type="text"  id="email" class="form-control" />
 </div>
<div class="form-group" style="font-weight:bold">
 <label>Enter your name</label>
  <input type="text"  id="name" class="form-control" />
  </div>
  <div class="form-group" style="font-weight:bold">
 <label>Enter password</label>
  <input type="password"  id="password" class="form-control" />
  </div>
 <div class="form-group">
    <input type="button" onclick="myFunction()"  style="background:rgb(2, 48, 49);font-weight:bold" id="submit" class="btn btn-info" value="signup" />
</div>
 <p>
  Already a member? <a href="login.php">Login</a>
  </p>
</form>
 </div>
 </div>
</div>
<div class="col-md-4">

    </div>
  </div>
</div>
</body>
</html>
<script>
function myFunction() {
var branch = document.getElementById("name").value;
var email = document.getElementById("email").value;
var password = document.getElementById("password").value;
// Returns successful data submission message when the entered information is stored in database.
var dataString = 'name1=' + branch + '&email1=' + email + '&password1=' + password;
if (branch == '' || email == '' || password == '') {
alert("Please Fill All Fields");
} else {
// AJAX code to submit form.
$.ajax({
type: "POST",
url: "signup_action.php",
data: dataString,
cache: false,
success: function(html) {
alert(html);
	$('#form')[0].reset();
}
});
}
return false;
}
</script>