<?php
include('admin/database_connection.php');
session_start();
$connect = mysql_connect("localhost", "root", "");
$db = mysql_select_db("attendance", $connect); // Selecting Database
if (isset($_POST['name1'])) {
 $subject = $_POST['name1'];
 $sql = "UPDATE tbl_teacher 
        SET teacher_grade_id= '$subject'
         WHERE teacher_id = '".$_SESSION["teacher_id"]."'";   
$query = mysql_query( $sql);

echo "subject has been saved";
}
?>