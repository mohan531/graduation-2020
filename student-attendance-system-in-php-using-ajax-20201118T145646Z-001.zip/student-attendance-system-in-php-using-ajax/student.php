<!DOCTYPE html>
<html lang="en">
<head>
  <title>Student Attendance System in PHP using Ajax</title>
  <style>
body{
  background-image: url('img1.jpg');
  background-repeat: no-repeat;
   background-attachment: fixed;
  background-size: cover;
}
ul{
  list-style-type: none;
  margin:0;
  padding:0;
  overflow: hidden;
  height:55px;
}
li a{
  font-family:fantasy;
  font-size:20px;
  display: block;
  color: ;
  text-align:center;
  padding: 15px 15px;
  text-decoration: none;
  margin-right:20px;
}

</style>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item"style="margin-right:60px" >
        <a class="nav-link" href="">Student Dashboard</a>
      </li> 
      <li><a class="nav-link" style="margin-left:1040px"href="homepage.php">Student Attendance Monitoring System</a></li>
    </ul>
  </div> 
</nav>

<<div class="container" style="margin-top:30px">
<div class="row">
    <div class="col-md-4">

    </div>
<div class="col-md-4" style="margin-top:20px;">
 <div class="card" style=" border: 2px solidrgb(0, 4, 8); border-radius: 0px 0px 10px 10px;">
  <div class="card-header" style="background: rgb(2, 48, 49);text-align:center;color:white;font-size:20px;font-family:fantasy"> Check Attendance</div>
<div class="card-body" style="backgorund:rgb(153, 153, 153)">
<form id="form" name="form"> 
  <div class="form_group" align="center">
          <button type="button" id="report_button" class="btn btn-danger btn-sm"> Attendance Report</button>
    
  </div>
  </form>	
      </div>
    </div>
  </div>
</div>
<div class="col-md-4">

    </div>
  </div>
</div>

</body>
</html>
<script type="text/javascript" src="js/bootstrap-datepicker.js"></script>
<link rel="stylesheet" href="css/datepicker.css" />

<style>
    .datepicker
    {
      z-index: 1600 !important; /* has to be larger than 1050 */
    }
</style>

<div class="modal" id="reportModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Check Attendance</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
      <div class="form-group">
              <label class="col-md-4 text-right">Roll num <span class="text-danger">*</span></label>
                <input type="text" name="grade_id" id="grade_id" class="form-control" />
                <span id="error_grade_id" class="text-danger"></span>
      </div>
          <div class="form-group">
          <div class="input-daterange">
            <input type="text" name="from_date" id="from_date" class="form-control" placeholder="From Date" readonly />
            <span id="error_from_date" class="text-danger"></span>
            <br />
            <input type="text" name="to_date" id="to_date" class="form-control" placeholder="To Date" readonly />
            <span id="error_to_date" class="text-danger"></span>
          </div>
        </div>
      </div>
      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" name="create_report" id="create_report" class="btn btn-success btn-sm">check</button>
        <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>

<div class="modal" id="chartModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Check Attendance</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
      <div class="form-group">
              <label class="col-md-4 text-right">Roll num <span class="text-danger">*</span></label>
                <input type="text" name="student_id" id="student_id" class="form-control" />
                <span id="error_grade_id" class="text-danger"></span>
      </div>
          <div class="form-group">
          <div class="input-daterange">
            <input type="text" name="fro_date" id="fro_date" class="form-control" placeholder="From Date" readonly />
            <span id="error_from_date" class="text-danger"></span>
            <br />
            <input type="text" name="t_date" id="t_date" class="form-control" placeholder="To Date" readonly />
            <span id="error_to_date" class="text-danger"></span>
          </div>
        </div>
      </div>
      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" name="create_chart" id="create_chart" class="btn btn-success btn-sm">check</button>
        <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>

<script>
$(document).ready(function(){

  $('.input-daterange').datepicker({
    todayBtn:"linked",
    format:"yyyy-mm-dd",
    autoclose:true,
    container: '#formModal modal-body'
  });

 $(document).on('click', '#report_button', function(){
    $('#reportModal').modal('show');
  });

   $(document).on('click', '#action_button', function(){
    $('#chartModal').modal('show');
  });

$('#create_report').click(function(){
    var grade_id = $('#grade_id').val();
    var from_date = $('#from_date').val();
    var to_date = $('#to_date').val();
    var error = 0;

    if(grade_id == '')
    {
      $('#error_grade_id').text('roll num is Required');
      error++;
    }
    else
    {
      $('#error_grade_id').text('');
    }

    if(from_date == '')
    {
      $('#error_from_date').text('From Date is Required');
      error++;
    }
    else
    {
      $('#error_from_date').text('');
    }

    if(to_date == '')
    {
      $('#error_to_date').text("To Date is Required");
      error++;
    }
    else
    {
      $('#error_to_date').text('');
    }

    if(error == 0)
    {
      $('#from_date').val('');
      $('#to_date').val('');
      $('#formModal').modal('hide');
      window.open("report_student.php?action=student_report&grade_id="+grade_id+"&from_date="+from_date+"&to_date="+to_date);
    }

  });
  
  $('#create_chart').click(function(){
    var grade_id = $('#student_id').val();
    var from_date = $('#fro_date').val();
    var to_date = $('#t_date').val();
    var error = 0;

    if(grade_id == '')
    {
      $('#error_grade_id').text('roll num is Required');
      error++;
    }
    else
    {
      $('#error_grade_id').text('');
    }

    if(from_date == '')
    {
      $('#error_from_date').text('From Date is Required');
      error++;
    }
    else
    {
      $('#error_from_date').text('');
    }

    if(to_date == '')
    {
      $('#error_to_date').text("To Date is Required");
      error++;
    }
    else
    {
      $('#error_to_date').text('');
    }

    if(error == 0)
    {
      $('#from_date').val('');
      $('#to_date').val('');
      $('#formModal').modal('hide');
      window.open("report_student.php?action=student_report&grade_id="+grade_id+"&from_date="+from_date+"&to_date="+to_date);
    }

  });
});
</script>