
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Student Attendance System in PHP using Ajax</title>
  <style>
body{
  background-image: url('img2.jpg');
  background-repeat: no-repeat;
   background-attachment: fixed;
  background-size: cover;
}
ul{
  list-style-type: none;
  margin:0;
  padding:0;
  overflow: hidden;
  height:55px;
}
li a{
  font-family:fantasy;
  font-size:20px;
  display: block;
  color: ;
  text-align:center;
  padding: 15px 15px;
  text-decoration: none;
  margin-right:20px;
}

</style>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item"style="margin-right:60px" >
        <a class="nav-link" href="student.php">Student</a>
      </li>
      <li class="nav-item" style="margin-right:60px">
        <a class="nav-link" href="login.php">Faculty</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="admin/login.php">Hod</a>
      </li>  
      <li><a class="nav-link" style="margin-left:920px"href="homepage.php">Student Attendance Monitoring System</a></li>
    </ul>
  </div> 
</nav>
</body>
</html>