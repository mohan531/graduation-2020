<?php

//profile.php

include('header.php');
?>

<html>
<body>
<div class="container" style="margin-top:30px">
<div class="row">
    <div class="col-md-4">

    </div>
<div class="col-md-4" style="margin-top:20px;">
 <div class="card" style=" border: 2px solidrgb(0, 4, 8); border-radius: 0px 0px 10px 10px;">
  <div class="card-header" style="background: rgb(2, 48, 49);text-align:center;color:white;font-size:20px;font-family:fantasy">select subject</div>
<div class="card-body" style="backgorund:rgb(153, 153, 153)">

<form id="form" name="form"> 
 <div class="form-group">
<label class="col-md-4 text-right">Subject <span class="text-danger">*</span></label>
<select  id="teacher_grade_id" class="form-control">
    <option value="">Select subject</option>
    <?php
    echo load_subject_list($connect);
    ?>
    </select>
	</div>
		
<div class="form-group">
    <input type="button" onclick="myFunction()"  style="background:rgb(2, 48, 49);font-weight:bold" id="submit" class="btn btn-info" value="save" />
</div>
</form>	
 </div>
 </div>
</div>
<div class="col-md-4">

    </div>
  </div>
</div>
</body>
</html>
<script>
function myFunction() {
var subject = document.getElementById("teacher_grade_id").value;
var dataString = 'name1=' + subject;
if (subject == '') {
alert("Please select subject");
} else {
// AJAX code to submit form.
$.ajax({
type: "POST",
url: "profile_action.php",
data: dataString,
cache: false,
success: function(html) {
alert(html);
	$('#form')[0].reset();
}
});
}
return false;
}
</script>