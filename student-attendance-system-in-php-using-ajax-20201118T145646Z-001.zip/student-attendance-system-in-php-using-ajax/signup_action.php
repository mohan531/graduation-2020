<?php

//check_admin_login.php
$connect = mysql_connect("localhost", "root", "");
$db = mysql_select_db("attendance", $connect); // Selecting Database
if (isset($_POST['name1'])) {
     $name2 = $_POST['name1'];
$email2 = $_POST['email1'];
$password2 = $_POST['password1'];
 $sql = "SELECT teacher_emailid FROM tbl_teacher WHERE teacher_emailid ='$email2'";
$resultset = mysql_query( $sql);
$row = COUNT($resultset);
if($row == 0){
$query = mysql_query("insert into tbl_teacher( teacher_emailid, teacher_password,teacher_name) values ( '$email2', '$password2','$name2')"); //Insert Query
echo "Form Submitted succesfully";
}
else {
echo "user already registered";
}

}
mysql_close($connect); // Connection Closed
?>